﻿using Microsoft.Maui.Controls.Shapes;
using Syncfusion.Maui.Charts;
using System.Runtime.InteropServices;
using GradientStop = Microsoft.Maui.Controls.GradientStop;
namespace MauiApp1;


public partial class MainPage : ContentPage
{
    DateTime globStart;
    DateTime globEnd;
    public Border CreateMission()
    {
        Border border = new Border
        {
            Stroke = Color.FromRgb(255, 255, 255),
            Background = Color.FromRgb(255, 255, 255),
            StrokeThickness = 4,

            StrokeShape = new RoundRectangle
            {
                CornerRadius = new CornerRadius(5, 5, 5, 5)
            },


        };
        Grid grid = new Grid
        {
            Padding = 10,

        };

        Label label = new Label
        {
            HorizontalOptions = LayoutOptions.Start,
            TextColor = Color.FromRgb(0, 0, 0),
            FontSize = 20,
            Text = "Job - Job Details"
        };
        Button button = new Button
        {
            HorizontalOptions = LayoutOptions.End,
            Text = "Submit",
            TextColor = Color.FromRgb(255, 255, 255),
            BackgroundColor = Color.FromRgb(0, 0, 0),

        };
        grid.Add(label);
        grid.Add(button);
        border.Content = grid;
        return border;
    }
    async void StratTime(object sender, EventArgs args)
    {
        ////calculate "Now" time
        //DateTime a = DateTime.Now;
        //globStart = a;
        ////send time to labal
        ////StartTimeShow.Text = a.ToString("t");
        //StartTimeShow.Text = "10:00";


        //test
        //DateTime Start = new DateTime(2000, 4, 1, 10, 0, 0);
        DateTime Start = DateTime.Now;
        globStart = Start;
        string now2 = Start.ToString("t");
        StartTimeShow.Text = now2;

    }
    async void EndTime(object sender, EventArgs args)
    {


        //calculate "Now" time
        DateTime a = DateTime.Now;
        globEnd = a;
        //send time to labal

        EndTimeShow.Text = a.ToString("t");



    }
    async void TotalTime(object sender, EventArgs args)
    {

        //calculate total time of the work
        TimeSpan TotalHours = globEnd - globStart;
        //send time to labal
        TotalTimeShow.Text = "Total Hours: " + TotalHours.ToString(@"hh\:mm");



        //Hours in int
        //string a = TotalHours.ToString("hh");
        //int b = Int32.Parse(a);
        //TotalTimeShow.Text = b.ToString();


    }



    public MainPage()
    {
        InitializeComponent();
        StackCurrent.Add(CreateMission());
        StackAdditional.Add(CreateMission());
        StackAdditional.Add(CreateMission());
        StackAdditional.Add(CreateMission());
        StackAdditional.Add(CreateMission());


        SfCartesianChart chart = new SfCartesianChart();
        chartxml.BindingContext = new ViewModel();


        CategoryAxis primaryAxis = new CategoryAxis();
        chart.XAxes.Add(primaryAxis);
        NumericalAxis secondaryAxis = new NumericalAxis();
        chart.YAxes.Add(secondaryAxis);


        
    }
}

public class Person
{
    public string Name { get; set; }
    public double Height { get; set; }
}

public class ViewModel
{
    public List<Person> Data { get; set; }

    public ViewModel()
    {
        Data = new List<Person>()
        {
            new Person { Name = "David", Height = 170 },
            new Person { Name = "Michael", Height = 96},
            new Person { Name = "Steve", Height = 65 },
            new Person { Name = "Joel", Height = 182 },
            new Person { Name = "Bob", Height = 134 }
        };
    }
}

public class Contact
{
    public string Name { get; set; }
}

public class ContactsViewModel
{
    public List<Contact> ListOfContacts { get; set; }

    public ContactsViewModel()
    {
        ListOfContacts = new List<Contact>();

        ListOfContacts.Add(new Contact() { Name = "Tucker Davis" });
        ListOfContacts.Add(new Contact() { Name = "Elizabeth Ann" });
        ListOfContacts.Add(new Contact() { Name = "Lily Sue" });
        ListOfContacts.Add(new Contact() { Name = "Mary Margaret" });
        ListOfContacts.Add(new Contact() { Name = "Sophia Grace" });
        ListOfContacts.Add(new Contact() { Name = "Andrew James" });
        ListOfContacts.Add(new Contact() { Name = "George Frances" });
        ListOfContacts.Add(new Contact() { Name = "James Richard" });
        ListOfContacts.Add(new Contact() { Name = "John Peter" });
        ListOfContacts.Add(new Contact() { Name = "Logan James" });
    }
}


