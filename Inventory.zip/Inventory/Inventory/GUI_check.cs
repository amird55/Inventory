﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventory
{
    class GUI_check
    {
        private mission m1;
        public void StartMission()
        {
             int empId = 2;
             DateTime start = new DateTime();
            start=DateTime.Today;
             int cardID =1;
             int processID=1;


            m1 = new mission(empId, start, start, cardID, processID, 0);

        }
        public void EndMission()
        {
            DateTime end = new DateTime();
            end = DateTime.Now;
            int quantity = 12;

            m1.EndMission(end, quantity);
        }
    }
}
