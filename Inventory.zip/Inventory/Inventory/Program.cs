﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Inventory;

GUI_check g = new GUI_check();
g.StartMission();
Console.WriteLine("started");
g.EndMission();
Console.WriteLine("finished");

